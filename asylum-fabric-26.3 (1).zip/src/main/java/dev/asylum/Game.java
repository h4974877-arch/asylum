package dev.asylum;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;

public final class Game {
	private static final Random R = new Random();

	public static void onJoin(ServerPlayer p) {
		if (Data.role(p) == Data.NORMAL && Data.timer(p) == -1 && Data.madness(p) == 0) {
			Data.setTimer(p, Data.TIMER_TICKS);
			p.sendSystemMessage(Component.literal("У тебя 10 минут, чтобы развиться. Потом тебя заберут в дурку.")
					.withStyle(ChatFormatting.RED));
		}
	}

	public static void tick(MinecraftServer server) {
		for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
			int role = Data.role(p);
			ServerLevel l = p.level();

			if (role == Data.NORMAL) {
				int t = Data.timer(p);
				if (t > 0) {
					t--;
					Data.setTimer(p, t);
					if (t % 20 == 0) showTimer(p, t / 20);
					if (t == 0) admit(p);
				}
			} else if (role == Data.PSYCHO) {
				if (p.hasEffect(MobEffects.REGENERATION)) { cure(p); continue; }
				if (l.dimension() == Asylum.KEY) {
					if (p.getY() < Asylum.Y0 - 4) toCell(p);
					else if (p.tickCount % 100 == 0) spawnMob(p, l);
				}
			} else if (role == Data.DOCTOR && p.tickCount % 10 == 0) {
				for (Mob m : l.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(20), m -> m.getTarget() == p))
					m.setTarget(null); // у врачей всё нормально: мобы дурки их не трогают
			}

			if (role != Data.DOCTOR && Data.madness(p) > 0) Hallucinations.tick(p);
			AsylumItems.tickLight(p);
		}
	}

	private static void showTimer(ServerPlayer p, int sec) {
		ChatFormatting c = sec <= 60 ? ChatFormatting.RED : sec <= 180 ? ChatFormatting.GOLD : ChatFormatting.YELLOW;
		p.sendSystemMessage(Component.literal(String.format("Осталось %02d:%02d", sec / 60, sec % 60)).withStyle(c), true);
	}

	public static void title(ServerPlayer p, String t, String sub) {
		p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
		p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(sub).withStyle(ChatFormatting.GRAY)));
		p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(t).withStyle(ChatFormatting.DARK_RED)));
	}

	/** Таймер кончился - в дурку. */
	public static void admit(ServerPlayer p) {
		MinecraftServer server = p.level().getServer();
		ServerLevel a = Asylum.level(server);
		if (a == null) {
			p.sendSystemMessage(Component.literal("Измерение asylum:asylum не загрузилось!").withStyle(ChatFormatting.RED));
			return;
		}
		Asylum.ensureBuilt(a);
		Hallucinations.reset(p);
		Data.setTimer(p, 0);
		Data.setRole(p, Data.PSYCHO);
		Data.setMadness(p, Math.max(1, Data.madness(p)));
		Vec3 v = Asylum.randomSpawn();
		p.teleportTo(a, v.x, v.y, v.z, Set.of(), p.getYRot(), 0f, true);
		p.playSound(SoundEvents.ENDERMAN_SCREAM, 1f, 0.5f);
		title(p, "ДУРКА", "Ты теперь псих. Свари зелье регенерации, чтобы выбраться.");
	}

	public static void toCell(ServerPlayer p) {
		ServerLevel a = Asylum.level(p.level().getServer());
		Vec3 v = Asylum.randomSpawn();
		p.teleportTo(a, v.x, v.y, v.z, Set.of(), p.getYRot(), 0f, true);
	}

	/** Побег №1: вылечился зельем регенерации - в обычный мир рядом с обычной больницей. */
	public static void cure(ServerPlayer p) {
		Hallucinations.reset(p);
		Data.setRole(p, Data.NORMAL);
		Data.setMadness(p, 0);
		Data.setTimer(p, 0);
		p.removeEffect(MobEffects.NAUSEA);
		p.removeEffect(MobEffects.DARKNESS);
		p.removeEffect(MobEffects.BLINDNESS);
		sendToHospital(p);
		title(p, "Ты вылечился", "Больше никаких голосов... наверное.");
	}

	public static void sendToHospital(ServerPlayer p) {
		ServerLevel ow = p.level().getServer().overworld();
		Vec3 v = Asylum.hospitalEntrance(ow);
		p.teleportTo(ow, v.x, v.y, v.z, Set.of(), 0f, 0f, true);
	}

	/** Побег №2: смерть. Шиза остаётся и усиливается. */
	public static void onDeath(ServerPlayer p) {
		if (Data.role(p) != Data.PSYCHO) return;
		Hallucinations.forget(p);
		Data.setRole(p, Data.NORMAL);
		Data.setMadness(p, Data.madness(p) + 1);
	}

	/** Психи не могут ломать пол и крышу дурки. */
	public static boolean canBreak(Level level, Player player, BlockPos pos) {
		if (level.dimension() == Asylum.KEY && player instanceof ServerPlayer sp
				&& Data.role(sp) == Data.PSYCHO && Asylum.isSlabY(pos.getY())) {
			sp.sendSystemMessage(Component.literal("Пол и потолок не поддаются...").withStyle(ChatFormatting.DARK_GRAY), true);
			return false;
		}
		return true;
	}

	/** Обычные мобы появляются только рядом с психами. */
	private static void spawnMob(ServerPlayer p, ServerLevel l) {
		if (l.getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(24)).size() >= 5) return;
		if (R.nextInt(3) == 0) return;
		EntityType<?>[] types = { EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.HUSK, EntityType.CAVE_SPIDER };
		for (int i = 0; i < 12; i++) {
			double a = R.nextDouble() * Math.PI * 2, d = 8 + R.nextDouble() * 10;
			BlockPos bp = BlockPos.containing(p.getX() + Math.cos(a) * d, p.getY(), p.getZ() + Math.sin(a) * d);
			if (l.getBlockState(bp).isAir() && l.getBlockState(bp.above()).isAir() && !l.getBlockState(bp.below()).isAir()) {
				var e = types[R.nextInt(types.length)].spawn(l, bp, EntitySpawnReason.EVENT);
				if (e instanceof Mob m) m.setPersistenceRequired();
				return;
			}
		}
	}
}
