package dev.asylum;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PositionMoveRotation;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Все галлюцинации - пакеты, отправляемые ТОЛЬКО самому психу: настоящий мир и другие игроки их не видят.
 * Враги/игроки-призраки - фейковые сущности, которых нет на сервере.
 */
public final class Hallucinations {
	private static final Random R = new Random();
	private static final Map<UUID, S> STATES = new HashMap<>();

	private static final class Fake {
		final Entity e; int ttl; final boolean chase; final boolean stare;
		Fake(Entity e, int ttl, boolean chase, boolean stare) { this.e = e; this.ttl = ttl; this.chase = chase; this.stare = stare; }
	}

	private static final class S {
		long next, boostUntil, sleepUntil;
		final List<Fake> fakes = new ArrayList<>();
		final Map<UUID, Fake> doctors = new HashMap<>();
		final Set<BlockPos> bloody = new HashSet<>();
		int roomKey = -1;
	}

	private static S st(ServerPlayer p) { return STATES.computeIfAbsent(p.getUUID(), k -> new S()); }

	/** Сбросить состояние без отправки пакетов (смерть, выход). */
	public static void forget(ServerPlayer p) { STATES.remove(p.getUUID()); }

	/** Убрать все галлюцинации с экрана игрока. */
	public static void reset(ServerPlayer p) {
		S s = STATES.remove(p.getUUID());
		if (s == null) return;
		for (Fake f : s.fakes) remove(p, f);
		for (Fake f : s.doctors.values()) remove(p, f);
		restoreBlood(p, s);
	}

	// --------------------------------------------------------- вызовы из предметов

	/** Таблетки врача: шиза развивается. */
	public static void pill(ServerPlayer p) {
		S s = st(p);
		s.boostUntil = p.level().getGameTime() + 20 * 90;
		s.next = 0;
		Data.setMadness(p, Data.madness(p) + 1);
		p.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 300, 0, false, false, false));
		p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0, false, false, false));
		Game.title(p, "§k||||", "голоса стали громче");
	}

	/** Шприц врача: псих засыпает. */
	public static void sleep(ServerPlayer p, int ticks) {
		S s = st(p);
		s.sleepUntil = p.level().getGameTime() + ticks;
		for (Fake f : s.fakes) remove(p, f);
		s.fakes.clear();
		restoreBlood(p, s);
		p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, ticks, 6, false, false, false));
		p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, ticks, 0, false, false, false));
		p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 3, false, false, false));
		p.removeEffect(MobEffects.NAUSEA);
		p.removeEffect(MobEffects.DARKNESS);
	}

	// ------------------------------------------------------------------- тик

	public static void tick(ServerPlayer p) {
		S s = st(p);
		ServerLevel l = p.level();
		long now = l.getGameTime();
		boolean asleep = now < s.sleepUntil;
		int lv = Math.min(10, Data.madness(p)) + (now < s.boostUntil ? 4 : 0);

		if (now % 5 == 0) doctors(p, s, l);
		tickFakes(p, s, l);
		if (asleep) return;

		if (now >= s.next) {
			event(p, s, l, lv);
			s.next = now + 30 + R.nextInt(Math.max(30, 500 / (lv + 1)));
		}
		if (l.dimension() == Asylum.KEY && now % 20 == 0) blood(p, s, l, lv);
	}

	private static void event(ServerPlayer p, S s, ServerLevel l, int lv) {
		switch (R.nextInt(lv >= 3 ? 10 : 6)) {
			case 0, 1 -> sound(p, l);
			case 2 -> mob(p, s, l, lv);
			case 3 -> phantomPlayer(p, s, l);
			case 4 -> {
				p.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 100 + lv * 20, 0, false, false, false));
				if (lv >= 2) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false, false));
				if (lv >= 5) p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 20 + lv * 3, 0, false, false, false));
			}
			case 5 -> {
				p.connection.send(new ClientboundHurtAnimationPacket(p));
				playAt(p, SoundEvents.PLAYER_HURT, p.getX(), p.getY(), p.getZ(), 1f, 1f);
			}
			case 6 -> title(p);
			case 7 -> lightning(p, s, l);
			default -> { mob(p, s, l, lv); sound(p, l); }
		}
	}

	// ----------------------------------------------------------------- звуки

	private static final SoundEvent[] SOUNDS = {
			SoundEvents.ZOMBIE_AMBIENT, SoundEvents.CREEPER_PRIMED, SoundEvents.ENDERMAN_SCREAM, SoundEvents.ENDERMAN_STARE,
			SoundEvents.GHAST_SCREAM, SoundEvents.WARDEN_HEARTBEAT, SoundEvents.SKELETON_AMBIENT, SoundEvents.WOODEN_DOOR_OPEN,
			SoundEvents.IRON_DOOR_OPEN, SoundEvents.CHEST_OPEN, SoundEvents.GLASS_BREAK, SoundEvents.SPIDER_AMBIENT,
			SoundEvents.WITCH_AMBIENT, SoundEvents.PHANTOM_AMBIENT, SoundEvents.WARDEN_NEARBY_CLOSE };

	public static void playAt(ServerPlayer p, SoundEvent ev, double x, double y, double z, float vol, float pitch) {
		p.connection.send(new ClientboundSoundPacket(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(ev),
				SoundSource.HOSTILE, x, y, z, vol, pitch, R.nextLong()));
	}

	private static void sound(ServerPlayer p, ServerLevel l) {
		double a = R.nextDouble() * Math.PI * 2, d = 3 + R.nextDouble() * 9;
		playAt(p, SOUNDS[R.nextInt(SOUNDS.length)], p.getX() + Math.cos(a) * d, p.getY(), p.getZ() + Math.sin(a) * d,
				1.2f, 0.6f + R.nextFloat() * 0.8f);
	}

	// -------------------------------------------------------- фейковые сущности

	private static Vec3 spot(ServerPlayer p, ServerLevel l, double dmin, double dmax) {
		for (int i = 0; i < 12; i++) {
			double a = R.nextDouble() * Math.PI * 2, d = dmin + R.nextDouble() * (dmax - dmin);
			double x = p.getX() + Math.cos(a) * d, z = p.getZ() + Math.sin(a) * d;
			BlockPos bp = BlockPos.containing(x, p.getY(), z);
			if (l.getBlockState(bp).isAir() && l.getBlockState(bp.above()).isAir() && !l.getBlockState(bp.below()).isAir())
				return new Vec3(x, bp.getY(), z);
		}
		return null;
	}

	private static float yawTo(Vec3 from, Vec3 to) {
		return (float) (Mth.atan2(to.z - from.z, to.x - from.x) * 57.29577951308232) - 90f;
	}

	private static Fake spawnFake(ServerPlayer p, ServerLevel l, EntityType<?> t, Vec3 pos, int ttl, boolean chase, boolean stare) {
		Entity e = t.create(l, EntitySpawnReason.EVENT);
		if (e == null) return null;
		float yaw = yawTo(pos, p.position());
		e.setPos(pos);
		e.setYRot(yaw);
		e.setYHeadRot(yaw);
		p.connection.send(new ClientboundAddEntityPacket(e.getId(), e.getUUID(), pos.x, pos.y, pos.z, 0f, yaw,
				e.getType(), 0, Vec3.ZERO, yaw));
		return new Fake(e, ttl, chase, stare);
	}

	private static void remove(ServerPlayer p, Fake f) {
		p.connection.send(new ClientboundRemoveEntitiesPacket(f.e.getId()));
	}

	private static void moveTo(ServerPlayer p, Fake f, Vec3 pos, float yaw) {
		f.e.setPos(pos);
		f.e.setYRot(yaw);
		f.e.setYHeadRot(yaw);
		p.connection.send(ClientboundTeleportEntityPacket.teleport(f.e.getId(),
				new PositionMoveRotation(pos, Vec3.ZERO, yaw, 0f), Set.of(), false));
		p.connection.send(new ClientboundRotateHeadPacket(f.e, (byte) Mth.floor(yaw * 256f / 360f)));
	}

	/** Мобы, которых нет. */
	private static void mob(ServerPlayer p, S s, ServerLevel l, int lv) {
		EntityType<?>[] pool = lv >= 5
				? new EntityType<?>[] { EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CREEPER, EntityType.ENDERMAN, EntityType.SPIDER, EntityType.WARDEN }
				: new EntityType<?>[] { EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CREEPER, EntityType.ENDERMAN, EntityType.SPIDER };
		Vec3 pos = spot(p, l, 5, 12);
		if (pos == null) return;
		boolean chase = R.nextInt(100) < 35 + lv * 4;
		Fake f = spawnFake(p, l, pool[R.nextInt(pool.length)], pos, chase ? 80 : 60, chase, !chase);
		if (f != null) s.fakes.add(f);
	}

	/** Игроки, которых нет: манекен, который молча смотрит. */
	private static void phantomPlayer(ServerPlayer p, S s, ServerLevel l) {
		Vec3 pos = spot(p, l, 6, 14);
		if (pos == null) return;
		Fake f = spawnFake(p, l, EntityType.MANNEQUIN, pos, 200, false, true);
		if (f != null) s.fakes.add(f);
	}

	private static void lightning(ServerPlayer p, S s, ServerLevel l) {
		Vec3 pos = spot(p, l, 8, 16);
		if (pos == null) return;
		Fake f = spawnFake(p, l, EntityType.LIGHTNING_BOLT, pos, 10, false, false);
		if (f != null) s.fakes.add(f);
		playAt(p, SoundEvents.LIGHTNING_BOLT_THUNDER, pos.x, pos.y, pos.z, 4f, 0.8f);
	}

	private static void tickFakes(ServerPlayer p, S s, ServerLevel l) {
		Iterator<Fake> it = s.fakes.iterator();
		while (it.hasNext()) {
			Fake f = it.next();
			Vec3 me = p.position(), at = f.e.position();
			double dist = at.distanceTo(me);
			if (--f.ttl <= 0 || (!f.chase && f.stare && dist < 3.5)) {
				remove(p, f);
				it.remove();
				continue;
			}
			if (f.chase) {
				if (dist < 1.6) {
					playAt(p, SoundEvents.PLAYER_HURT, me.x, me.y, me.z, 1f, 0.7f);
					p.connection.send(new ClientboundHurtAnimationPacket(p));
					remove(p, f);
					it.remove();
					continue;
				}
				Vec3 dir = me.subtract(at).normalize().scale(0.17);
				moveTo(p, f, new Vec3(at.x + dir.x, at.y, at.z + dir.z), yawTo(at, me));
			} else if (f.stare && p.tickCount % 4 == 0 && f.e.getType() != EntityType.LIGHTNING_BOLT) {
				moveTo(p, f, at, yawTo(at, me));
			}
		}
		// фейки-врачи следуют за настоящими врачами
		for (var e : s.doctors.entrySet()) {
			ServerPlayer d = l.getServer().getPlayerList().getPlayer(e.getKey());
			if (d != null) moveTo(p, e.getValue(), d.position(), d.getYRot());
		}
	}

	/** Врач для психа - чёрный человек с открытой пастью (кричащий эндермен), настоящий врач скрыт. */
	private static void doctors(ServerPlayer p, S s, ServerLevel l) {
		Set<UUID> seen = new HashSet<>();
		for (ServerPlayer d : l.players()) {
			if (Data.role(d) != Data.DOCTOR || d.distanceToSqr(p) > 48 * 48) continue;
			seen.add(d.getUUID());
			p.connection.send(new ClientboundRemoveEntitiesPacket(d.getId()));
			if (!s.doctors.containsKey(d.getUUID())) {
				Fake f = spawnFake(p, l, EntityType.ENDERMAN, d.position(), Integer.MAX_VALUE, false, false);
				if (f == null) continue;
				if (f.e instanceof EnderMan em) {
					em.setBeingStaredAt(); // открытая пасть
					var data = em.getEntityData().getNonDefaultValues();
					if (data != null) p.connection.send(new ClientboundSetEntityDataPacket(em.getId(), data));
				}
				s.doctors.put(d.getUUID(), f);
			}
		}
		Iterator<Map.Entry<UUID, Fake>> it = s.doctors.entrySet().iterator();
		while (it.hasNext()) {
			var e = it.next();
			if (!seen.contains(e.getKey())) { remove(p, e.getValue()); it.remove(); }
		}
	}

	// ------------------------------------------------------- экран и кровавые комнаты

	private static void title(ServerPlayer p) {
		String[] t = { "ОН ЗА ТОБОЙ", "ОНИ ВИДЯТ ТЕБЯ", "НЕ ОБОРАЧИВАЙСЯ", "ТЫ НЕ ОДИН", "ВРАЧ ЛЖЁТ", "ТЫ ЗДЕСЬ НАВСЕГДА", "ОТКРОЙ ГЛАЗА" };
		var c = Component.literal(t[R.nextInt(t.length)]).withStyle(ChatFormatting.DARK_RED);
		if (R.nextBoolean()) c = c.withStyle(ChatFormatting.OBFUSCATED);
		p.connection.send(new ClientboundSetTitlesAnimationPacket(0, 15, 10));
		p.connection.send(new ClientboundSetTitleTextPacket(c));
	}

	private static BlockState bloody(BlockState s) {
		if (s.is(Blocks.DEEPSLATE_TILES)) return Blocks.NETHER_WART_BLOCK.defaultBlockState();
		if (s.is(Blocks.STONE_BRICKS) || s.is(Blocks.CRACKED_STONE_BRICKS) || s.is(Blocks.MOSSY_STONE_BRICKS))
			return Blocks.RED_NETHER_BRICKS.defaultBlockState();
		if (s.is(Blocks.WHITE_WOOL) || s.is(Blocks.QUARTZ_BLOCK)) return Blocks.RED_WOOL.defaultBlockState();
		return null;
	}

	/** Иногда вместо обычной комнаты псих видит окровавленную (только у него на экране). */
	private static void blood(ServerPlayer p, S s, ServerLevel l, int lv) {
		BlockPos bp = p.blockPosition();
		int i = bp.getX() / Asylum.CELL, j = bp.getZ() / Asylum.CELL;
		if (bp.getX() < 0 || bp.getZ() < 0 || i >= Asylum.N || j >= Asylum.N) return;
		int f = Asylum.floorOf(p.getY());
		int key = (f * Asylum.N + j) * Asylum.N + i;
		if (key == s.roomKey) return;
		restoreBlood(p, s);
		s.roomKey = key;
		if (R.nextInt(100) >= 12 + lv * 4) return;
		int base = Asylum.Y0 + f * Asylum.PITCH;
		for (int x = i * Asylum.CELL; x <= (i + 1) * Asylum.CELL; x++)
			for (int z = j * Asylum.CELL; z <= (j + 1) * Asylum.CELL; z++)
				for (int y = base; y < base + Asylum.PITCH; y++) {
					BlockPos pos = new BlockPos(x, y, z);
					BlockState repl = bloody(l.getBlockState(pos));
					if (repl == null) continue;
					p.connection.send(new ClientboundBlockUpdatePacket(pos, repl));
					s.bloody.add(pos);
				}
		playAt(p, SoundEvents.WARDEN_HEARTBEAT, p.getX(), p.getY(), p.getZ(), 2f, 0.7f);
	}

	private static void restoreBlood(ServerPlayer p, S s) {
		ServerLevel l = p.level();
		for (BlockPos pos : s.bloody) p.connection.send(new ClientboundBlockUpdatePacket(pos, l.getBlockState(pos)));
		s.bloody.clear();
		s.roomKey = -1;
	}
}
