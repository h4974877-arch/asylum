package dev.asylum;

import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Предметы врача сделаны на ванильных предметах + custom_data, поэтому моду не нужны ресурспак и клиентская часть:
 * Таблетки = сахар, Шприц = стрела, Фонарик = огненный стержень.
 */
public final class AsylumItems {
	private static final Map<UUID, List<BlockPos>> LIGHTS = new HashMap<>();

	public static void init() {
		UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
			if (level.isClientSide()) return InteractionResult.PASS;
			if (!(player instanceof ServerPlayer doc) || !(entity instanceof ServerPlayer target)) return InteractionResult.PASS;
			if (Data.role(doc) != Data.DOCTOR || Data.role(target) == Data.DOCTOR || Data.madness(target) <= 0)
				return InteractionResult.PASS;
			ItemStack stack = doc.getItemInHand(hand);
			switch (type(stack)) {
				case "pills" -> {
					if (!doc.getAbilities().instabuild) stack.shrink(1);
					Hallucinations.pill(target);
					return InteractionResult.SUCCESS;
				}
				case "syringe" -> {
					if (!doc.getAbilities().instabuild) stack.shrink(1);
					Hallucinations.sleep(target, 20 * 30);
					return InteractionResult.SUCCESS;
				}
				default -> { return InteractionResult.PASS; }
			}
		});
	}

	// ---------------------------------------------------------------- предметы

	public static String type(ItemStack s) {
		CustomData cd = s.get(DataComponents.CUSTOM_DATA);
		return cd == null ? "" : cd.copyTag().getStringOr("asylum", "");
	}

	private static ItemStack make(Item base, int count, String type, String name, ChatFormatting color) {
		ItemStack s = new ItemStack(base, count);
		CustomData.update(DataComponents.CUSTOM_DATA, s, t -> t.putString("asylum", type));
		s.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(Style.EMPTY.withItalic(false).withColor(color)));
		return s;
	}

	public static ItemStack pills(int n) { return make(Items.SUGAR, n, "pills", "Таблетки", ChatFormatting.AQUA); }
	public static ItemStack syringe(int n) { return make(Items.ARROW, n, "syringe", "Шприц", ChatFormatting.GREEN); }
	public static ItemStack flashlight() { return make(Items.BLAZE_ROD, 1, "flashlight", "Фонарик", ChatFormatting.YELLOW); }

	public static void giveKit(ServerPlayer p) {
		for (ItemStack s : List.of(pills(16), syringe(8), flashlight())) {
			if (!p.addItem(s)) p.drop(s, false);
		}
	}

	// ----------------------------------------------------------------- фонарик

	/** Фонарик: невидимый блок света в точке, куда смотрит игрок + мягкий свет перед ним. */
	public static void tickLight(ServerPlayer p) {
		boolean holding = type(p.getMainHandItem()).equals("flashlight") || type(p.getOffhandItem()).equals("flashlight");
		if (!holding) { clearLight(p); return; }

		ServerLevel l = p.level();
		HitResult hr = p.pick(24.0, 1.0f, false);
		BlockPos far = hr instanceof BlockHitResult b && hr.getType() == HitResult.Type.BLOCK
				? b.getBlockPos().relative(b.getDirection()) : BlockPos.containing(hr.getLocation());
		Vec3 eye = p.getEyePosition();
		BlockPos near = BlockPos.containing(eye.add(p.getLookAngle().scale(3)));

		List<BlockPos> want = List.of(far, near);
		if (want.equals(LIGHTS.get(p.getUUID()))) return;
		clearLight(p);
		List<BlockPos> placed = new ArrayList<>();
		int[] levels = { 15, 10 };
		for (int i = 0; i < want.size(); i++) {
			BlockPos bp = want.get(i);
			if (l.getBlockState(bp).isAir()) {
				l.setBlock(bp, Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, levels[i]), 2);
				placed.add(bp);
			}
		}
		LIGHTS.put(p.getUUID(), placed);
	}

	public static void clearLight(ServerPlayer p) {
		List<BlockPos> old = LIGHTS.remove(p.getUUID());
		if (old == null) return;
		ServerLevel l = p.level();
		for (BlockPos bp : old) {
			BlockState s = l.getBlockState(bp);
			if (s.is(Blocks.LIGHT)) l.setBlock(bp, Blocks.AIR.defaultBlockState(), 2);
		}
	}
}
