package dev.asylum;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Постройка дурки (4 этажа, лабиринт комнат 4x4 на этаж) и обычной больницы в верхнем мире. */
public final class Asylum {
	public static final ResourceKey<Level> KEY = ResourceKey.create(Registries.DIMENSION, AsylumMod.id("asylum"));

	public static final int N = 4;            // комнат по стороне
	public static final int CELL = 11;        // шаг комнаты (10 внутри + 1 стена)
	public static final int SIZE = N * CELL + 1;
	public static final int FLOORS = 4;
	public static final int Y0 = 64;          // уровень пола 1-го этажа
	public static final int PITCH = 6;        // 1 плита + 5 воздуха

	private static final Random R = new Random();

	public static ServerLevel level(MinecraftServer s) { return s.getLevel(KEY); }

	/** Пол/потолок этажей - психи их ломать не могут. */
	public static boolean isSlabY(int y) {
		return y >= Y0 && y <= Y0 + FLOORS * PITCH && (y - Y0) % PITCH == 0;
	}

	public static int floorOf(double y) {
		return Mth.clamp((int) Math.floor((y - Y0) / PITCH), 0, FLOORS - 1);
	}

	public static boolean built(ServerLevel l) {
		return l.getBlockState(new BlockPos(1, Y0, 1)).is(Blocks.DEEPSLATE_TILES);
	}

	public static Vec3 randomSpawn() {
		int f = R.nextInt(FLOORS), i = R.nextInt(N), j = R.nextInt(N);
		return new Vec3(i * CELL + 5.5, Y0 + f * PITCH + 1, j * CELL + 5.5);
	}

	public static Vec3 entranceSpawn() { return new Vec3(5.5, Y0 + 1, 5.5); }

	private static void set(ServerLevel l, int x, int y, int z, BlockState s) {
		l.setBlock(new BlockPos(x, y, z), s, 2 | 16);
	}

	private static ItemStack water() { return PotionContents.createItemStack(net.minecraft.world.item.Items.POTION, Potions.WATER); }

	public static void ensureBuilt(ServerLevel l) {
		if (!built(l)) build(l);
	}

	// ------------------------------------------------------------------ дурка

	private static void carve(int i, int j, boolean[][] vis, boolean[][] right, boolean[][] down, Random r) {
		vis[i][j] = true;
		List<Integer> dirs = new ArrayList<>(List.of(0, 1, 2, 3));
		Collections.shuffle(dirs, r);
		for (int d : dirs) {
			int ni = i + (d == 0 ? 1 : d == 1 ? -1 : 0);
			int nj = j + (d == 2 ? 1 : d == 3 ? -1 : 0);
			if (ni < 0 || nj < 0 || ni >= N || nj >= N || vis[ni][nj]) continue;
			if (d == 0) right[i][j] = true;
			if (d == 1) right[ni][nj] = true;
			if (d == 2) down[i][j] = true;
			if (d == 3) down[ni][nj] = true;
			carve(ni, nj, vis, right, down, r);
		}
	}

	private static void build(ServerLevel l) {
		Random r = new Random(l.getSeed() ^ 0xA51L);
		BlockState[] bricks = {
				Blocks.STONE_BRICKS.defaultBlockState(), Blocks.STONE_BRICKS.defaultBlockState(),
				Blocks.CRACKED_STONE_BRICKS.defaultBlockState(), Blocks.MOSSY_STONE_BRICKS.defaultBlockState() };
		BlockState floor = Blocks.DEEPSLATE_TILES.defaultBlockState();
		BlockState air = Blocks.AIR.defaultBlockState();

		List<BlockPos> chests = new ArrayList<>();
		List<Vec3> eyes = new ArrayList<>();

		for (int f = 0; f < FLOORS; f++) {
			int base = Y0 + f * PITCH;
			boolean[][] vis = new boolean[N][N], right = new boolean[N][N], down = new boolean[N][N];
			carve(r.nextInt(N), r.nextInt(N), vis, right, down, r);
			for (int k = 0; k < 5; k++) { // лишние двери, чтобы не был идеальный лабиринт
				int i = r.nextInt(N - 1), j = r.nextInt(N - 1);
				if (r.nextBoolean()) right[i][j] = true; else down[i][j] = true;
			}

			// пол
			for (int x = 0; x < SIZE; x++) for (int z = 0; z < SIZE; z++) set(l, x, base, z, floor);
			// крыша последнего этажа
			if (f == FLOORS - 1)
				for (int x = 0; x < SIZE; x++) for (int z = 0; z < SIZE; z++) set(l, x, base + PITCH, z, floor);
			// стены
			for (int x = 0; x < SIZE; x++) for (int z = 0; z < SIZE; z++) {
				if (x % CELL == 0 || z % CELL == 0)
					for (int dy = 1; dy < PITCH; dy++) set(l, x, base + dy, z, bricks[r.nextInt(bricks.length)]);
			}
			// двери между комнатами (2 в ширину, 2 в высоту)
			for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
				if (i < N - 1 && right[i][j])
					for (int dz = 5; dz <= 6; dz++) for (int dy = 1; dy <= 2; dy++)
						set(l, (i + 1) * CELL, base + dy, j * CELL + dz, air);
				if (j < N - 1 && down[i][j])
					for (int dx = 5; dx <= 6; dx++) for (int dy = 1; dy <= 2; dy++)
						set(l, i * CELL + dx, base + dy, (j + 1) * CELL, air);
			}
			// содержимое комнат
			int labI = r.nextInt(N), labJ = r.nextInt(N);
			for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
				int x0 = i * CELL, z0 = j * CELL;
				int type = (i == labI && j == labJ) ? 2 : r.nextInt(5);
				switch (type) {
					case 0 -> { // мягкая палата
						for (int x = 1; x <= 10; x++) for (int z = 1; z <= 10; z++)
							set(l, x0 + x, base, z0 + z, Blocks.WHITE_WOOL.defaultBlockState());
					}
					case 1 -> { // морг
						for (int x = 1; x <= 10; x++) for (int z = 1; z <= 10; z++)
							set(l, x0 + x, base, z0 + z, Blocks.QUARTZ_BLOCK.defaultBlockState());
					}
					case 2 -> { // лаборатория с варочной стойкой
						set(l, x0 + 3, base + 1, z0 + 3, Blocks.BREWING_STAND.defaultBlockState());
						set(l, x0 + 4, base + 1, z0 + 3, Blocks.WATER_CAULDRON.defaultBlockState());
					}
					case 3 -> { // камера за решёткой
						for (int z = 1; z <= 10; z++) for (int dy = 1; dy <= 3; dy++)
							if (z != 5 && z != 6) set(l, x0 + 6, base + dy, z0 + z, Blocks.IRON_BARS.defaultBlockState());
					}
					default -> { // паутина и мусор
						for (int k = 0; k < 10; k++)
							set(l, x0 + 1 + r.nextInt(10), base + 1 + r.nextInt(4), z0 + 1 + r.nextInt(10),
									Blocks.COBWEB.defaultBlockState());
					}
				}
				for (int k = 0, n = 1 + r.nextInt(2); k < n; k++) {
					BlockPos cp = new BlockPos(x0 + 1 + r.nextInt(10), base + 1, z0 + 1 + r.nextInt(10));
					if (l.getBlockState(cp).isAir()) {
						l.setBlock(cp, Blocks.CHEST.defaultBlockState(), 2);
						chests.add(cp);
					}
				}
				for (int k = 0; k < 2; k++)
					eyes.add(new Vec3(x0 + 2 + r.nextInt(8) + 0.5, base + 2 + r.nextInt(3), z0 + 2 + r.nextInt(8) + 0.5));
			}
		}

		// лестницы-лазы (два лаза на каждый переход между этажами)
		for (int f = 0; f < FLOORS - 1; f++) {
			int base = Y0 + f * PITCH;
			for (int y = base + 1; y <= base + PITCH; y++) {
				set(l, 1, y, 1, Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH));
				set(l, SIZE - 2, y, SIZE - 2, Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.NORTH));
			}
		}

		fillChests(l, chests, r);

		// глаза: billboard-дисплеи, всегда смотрят на зрителя
		MinecraftServer server = l.getServer();
		var src = server.createCommandSourceStack().withSuppressedOutput();
		for (Vec3 e : eyes) {
			server.getCommands().performPrefixedCommand(src, String.format(Locale.ROOT,
					"execute in %s run summon item_display %.2f %.2f %.2f {item:{id:\"minecraft:ender_eye\",count:1},billboard:\"center\",Tags:[\"asylum_eye\"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}",
					KEY.identifier(), e.x, e.y, e.z));
		}
	}

	private static void fillChests(ServerLevel l, List<BlockPos> chests, Random r) {
		if (chests.isEmpty()) return;
		List<net.minecraft.world.item.Item> junk = List.of(Items.BREAD, Items.ROTTEN_FLESH, Items.PAPER, Items.STRING,
				Items.BONE, Items.IRON_INGOT, Items.GLASS_BOTTLE, Items.BOOK, Items.SPIDER_EYE, Items.FEATHER,
				Items.LEATHER, Items.STONE_SWORD, Items.LEATHER_CHESTPLATE, Items.COOKED_CHICKEN, Items.APPLE);
		Map<BlockPos, List<ItemStack>> loot = new HashMap<>();
		for (BlockPos c : chests) {
			List<ItemStack> list = new ArrayList<>();
			for (int k = 0, n = 2 + r.nextInt(4); k < n; k++)
				list.add(new ItemStack(junk.get(r.nextInt(junk.size())), 1 + r.nextInt(3)));
			loot.put(c, list);
		}
		// ресурсы для зелья регенерации раскиданы случайно по всей дурке
		List<ItemStack> keys = new ArrayList<>();
		for (int k = 0; k < 4; k++) keys.add(new ItemStack(Items.GHAST_TEAR, 1));
		for (int k = 0; k < 5; k++) keys.add(new ItemStack(Items.NETHER_WART, 2));
		for (int k = 0; k < 4; k++) keys.add(new ItemStack(Items.BLAZE_POWDER, 2));
		for (int k = 0; k < 6; k++) keys.add(water());
		for (int k = 0; k < 3; k++) keys.add(new ItemStack(Items.BREWING_STAND, 1));
		for (ItemStack s : keys) loot.get(chests.get(r.nextInt(chests.size()))).add(s);

		for (var e : loot.entrySet()) {
			if (!(l.getBlockEntity(e.getKey()) instanceof ChestBlockEntity ch)) continue;
			List<Integer> slots = new ArrayList<>();
			for (int i = 0; i < ch.getContainerSize(); i++) slots.add(i);
			Collections.shuffle(slots, r);
			for (int i = 0; i < e.getValue().size() && i < slots.size(); i++) ch.setItem(slots.get(i), e.getValue().get(i));
			ch.setChanged();
		}
	}

	// ------------------------------------------------- обычная больница в верхнем мире

	private static final int HX = 96, HZ = 96;

	public static Vec3 hospitalEntrance(ServerLevel ow) {
		Integer y = ow.getAttached(Data.HOSPITAL_Y);
		if (y == null) {
			y = buildHospital(ow);
			ow.setAttached(Data.HOSPITAL_Y, y);
		}
		return new Vec3(HX + 0.5, y + 1, HZ + 10.5);
	}

	private static int buildHospital(ServerLevel l) {
		for (int cx = (HX - 12) >> 4; cx <= (HX + 12) >> 4; cx++)
			for (int cz = (HZ - 12) >> 4; cz <= (HZ + 12) >> 4; cz++) l.getChunk(cx, cz);
		int y = Integer.MIN_VALUE;
		for (int dx = -8; dx <= 8; dx += 8) for (int dz = -8; dz <= 8; dz += 8)
			y = Math.max(y, l.getHeight(Heightmap.Types.WORLD_SURFACE, HX + dx, HZ + dz));
		y = Math.max(y, l.getSeaLevel()) + 0;

		BlockState wall = Blocks.WHITE_CONCRETE.defaultBlockState();
		BlockState air = Blocks.AIR.defaultBlockState();
		for (int x = HX - 9; x <= HX + 9; x++) for (int z = HZ - 9; z <= HZ + 12; z++) {
			for (int dy = -4; dy < 0; dy++) set(l, x, y + dy, z, Blocks.STONE_BRICKS.defaultBlockState());
			set(l, x, y, z, Blocks.STONE_BRICKS.defaultBlockState());
			for (int dy = 1; dy <= 9; dy++) set(l, x, y + dy, z, air);
		}
		for (int x = HX - 7; x <= HX + 7; x++) for (int z = HZ - 7; z <= HZ + 7; z++) {
			set(l, x, y, z, Blocks.QUARTZ_BLOCK.defaultBlockState());
			set(l, x, y + 6, z, wall);
			boolean edge = x == HX - 7 || x == HX + 7 || z == HZ - 7 || z == HZ + 7;
			for (int dy = 1; dy <= 5; dy++) {
				if (!edge) continue;
				boolean window = dy == 3 && ((x + z) % 3 == 0);
				set(l, x, y + dy, z, window ? Blocks.GLASS_PANE.defaultBlockState() : wall);
			}
			if (!edge && x % 4 == 0 && z % 4 == 0) set(l, x, y + 5, z, Blocks.SEA_LANTERN.defaultBlockState());
		}
		for (int x = HX - 1; x <= HX + 1; x++) for (int dy = 1; dy <= 3; dy++) set(l, x, y + dy, HZ + 7, air);
		BlockState red = Blocks.RED_CONCRETE.defaultBlockState();
		set(l, HX, y + 4, HZ + 7, red); set(l, HX, y + 5, HZ + 7, red);
		set(l, HX - 1, y + 5, HZ + 7, red); set(l, HX + 1, y + 5, HZ + 7, red);
		return y;
	}
}
