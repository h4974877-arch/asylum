package dev.asylum;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

public class AsylumMod implements ModInitializer {
	public static final String ID = "asylum";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(ID, path);
	}

	@Override
	public void onInitialize() {
		Data.init();
		AsylumCommands.init();
		AsylumItems.init();

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> Game.onJoin(handler.getPlayer()));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			Hallucinations.forget(handler.getPlayer());
			AsylumItems.clearLight(handler.getPlayer());
		});
		ServerTickEvents.END_SERVER_TICK.register(Game::tick);
		PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, be) -> Game.canBreak(level, player, pos));
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (entity instanceof ServerPlayer p) Game.onDeath(p);
		});
	}
}
