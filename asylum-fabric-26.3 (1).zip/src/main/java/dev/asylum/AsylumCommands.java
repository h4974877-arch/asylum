package dev.asylum;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.Set;
import java.util.function.Predicate;

/**
 * /asylum doctor [игрок]   - сделать врачом / снять (оператор). Врач получает таблетки, шприцы, фонарик.
 * /asylum admit <игрок>    - сразу отправить в дурку
 * /asylum cure <игрок>     - вылечить (в т.ч. тех, кто остался с шизой в обычном мире)
 * /asylum timer <игрок> <секунды> - запустить таймер заново
 * /asylum kit              - выдать набор врача (врач/оператор)
 * /asylum visit | leave    - врач заходит в дурку / выходит (врач/оператор)
 */
public final class AsylumCommands {
	private static final Predicate<CommandSourceStack> OP = Commands.hasPermission(Commands.LEVEL_GAMEMASTERS);
	private static final Predicate<CommandSourceStack> DOC_OR_OP = s -> {
		if (OP.test(s)) return true;
		ServerPlayer p = s.getPlayer();
		return p != null && Data.role(p) == Data.DOCTOR;
	};

	public static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, ctx, env) -> dispatcher.register(
				Commands.literal("asylum")
						.then(Commands.literal("doctor").requires(OP)
								.executes(c -> doctor(c.getSource(), c.getSource().getPlayerOrException()))
								.then(Commands.argument("player", EntityArgument.player())
										.executes(c -> doctor(c.getSource(), EntityArgument.getPlayer(c, "player")))))
						.then(Commands.literal("admit").requires(OP)
								.then(Commands.argument("player", EntityArgument.player()).executes(c -> {
									Game.admit(EntityArgument.getPlayer(c, "player"));
									return 1;
								})))
						.then(Commands.literal("cure").requires(OP)
								.then(Commands.argument("player", EntityArgument.player()).executes(c -> {
									Game.cure(EntityArgument.getPlayer(c, "player"));
									return 1;
								})))
						.then(Commands.literal("timer").requires(OP)
								.then(Commands.argument("player", EntityArgument.player())
										.then(Commands.argument("seconds", IntegerArgumentType.integer(1, 36000)).executes(c -> {
											ServerPlayer p = EntityArgument.getPlayer(c, "player");
											Data.setRole(p, Data.NORMAL);
											Data.setTimer(p, IntegerArgumentType.getInteger(c, "seconds") * 20);
											return 1;
										}))))
						.then(Commands.literal("kit").requires(DOC_OR_OP).executes(c -> {
							AsylumItems.giveKit(c.getSource().getPlayerOrException());
							return 1;
						}))
						.then(Commands.literal("visit").requires(DOC_OR_OP).executes(c -> {
							ServerPlayer p = c.getSource().getPlayerOrException();
							ServerLevel a = Asylum.level(c.getSource().getServer());
							Asylum.ensureBuilt(a);
							Vec3 v = Asylum.entranceSpawn();
							p.teleportTo(a, v.x, v.y, v.z, Set.of(), p.getYRot(), 0f, true);
							return 1;
						}))
						.then(Commands.literal("leave").requires(DOC_OR_OP).executes(c -> {
							Game.sendToHospital(c.getSource().getPlayerOrException());
							return 1;
						}))));
	}

	private static int doctor(CommandSourceStack src, ServerPlayer p) {
		boolean make = Data.role(p) != Data.DOCTOR;
		Hallucinations.reset(p);
		if (make) {
			Data.setRole(p, Data.DOCTOR);
			Data.setMadness(p, 0);
			Data.setTimer(p, 0);
			AsylumItems.giveKit(p);
		} else {
			Data.setRole(p, Data.NORMAL);
			Data.setTimer(p, 0);
		}
		src.sendSuccess(() -> Component.literal(p.getName().getString() + (make ? " теперь врач" : " больше не врач"))
				.withStyle(ChatFormatting.GREEN), true);
		return 1;
	}
}
