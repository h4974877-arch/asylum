package dev.asylum;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.server.level.ServerPlayer;

/** Всё состояние игрока хранится в data attachments (сохраняется в мире, переживает смерть). */
public final class Data {
	public static final int NORMAL = 0, PSYCHO = 1, DOCTOR = 2;
	/** 10 минут = 12000 тиков. */
	public static final int TIMER_TICKS = 20 * 60 * 10;

	/** -1 = таймер ещё не запускался, 0 = закончился/не нужен, >0 = осталось тиков. */
	public static final AttachmentType<Integer> TIMER = AttachmentRegistry.<Integer>create(
			AsylumMod.id("timer"), b -> b.initializer(() -> -1).persistent(Codec.INT).copyOnDeath());
	public static final AttachmentType<Integer> ROLE = AttachmentRegistry.<Integer>create(
			AsylumMod.id("role"), b -> b.initializer(() -> NORMAL).persistent(Codec.INT).copyOnDeath());
	/** Уровень шизы 0..10. Остаётся после смерти. */
	public static final AttachmentType<Integer> MADNESS = AttachmentRegistry.<Integer>create(
			AsylumMod.id("madness"), b -> b.initializer(() -> 0).persistent(Codec.INT).copyOnDeath());
	/** Высота, на которой построена обычная психбольница в верхнем мире (вешается на ServerLevel). */
	public static final AttachmentType<Integer> HOSPITAL_Y = AttachmentRegistry.<Integer>create(
			AsylumMod.id("hospital_y"), b -> b.persistent(Codec.INT));

	public static void init() { }

	public static int timer(ServerPlayer p) { return p.getAttachedOrCreate(TIMER); }
	public static int role(ServerPlayer p) { return p.getAttachedOrCreate(ROLE); }
	public static int madness(ServerPlayer p) { return p.getAttachedOrCreate(MADNESS); }
	public static void setTimer(ServerPlayer p, int v) { p.setAttached(TIMER, v); }
	public static void setRole(ServerPlayer p, int v) { p.setAttached(ROLE, v); }
	public static void setMadness(ServerPlayer p, int v) { p.setAttached(MADNESS, Math.max(0, Math.min(10, v))); }
}
